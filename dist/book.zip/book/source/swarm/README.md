# Docker Swarm 项目
Docker Swarm 是 Docker 官方编排（Orchestration）项目之一，负责对 Docker 集群进行管理。

本章将介绍 Swarm 项目情况以及安装和使用。
