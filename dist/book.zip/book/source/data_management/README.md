# Docker 数据管理
这一章介绍如何在 Docker 内部以及容器之间管理数据，在容器中管理数据主要有两种方式：
* 数据卷（Data volumes）
* 数据卷容器（Data volume containers）
