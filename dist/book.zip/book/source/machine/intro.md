## 简介

![Docker Machine](../_images/docker_machine.png)

Docker Machine 项目基于 Go 语言实现，目前在 [Github](https://github.com/docker/machine) 上进行维护。

技术讨论 IRC 频道为 `#docker-machine`。
