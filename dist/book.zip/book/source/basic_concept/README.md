# 基本概念
Docker 包括三个基本概念
* 镜像（Image）
* 容器（Container）
* 仓库（Repository）

理解了这三个概念，就理解了 Docker 的整个生命周期。

