## 简介
Mesos 是一个集群资源的自动调度平台，Apache 开源项目，它的定位是要做数据中心操作系统的内核。目前由 Mesosphere 公司维护，更多信息可以自行查阅 [Mesos 项目地址](http://mesos.apache.org/)或 [Mesosphere](https://mesosphere.com)。
