## 容器格式
最初，Docker 采用了 LXC 中的容器格式。自 1.20 版本开始，Docker 也开始支持新的 [libcontainer](https://github.com/docker/libcontainer) 格式，并作为默认选项。

对更多容器格式的支持，还在进一步的发展中。
