# 安装
官方网站上有各种环境下的 [安装指南](https://docs.docker.com/installation/#installation)，这里主要介绍下Ubuntu和CentOS系列的安装。
