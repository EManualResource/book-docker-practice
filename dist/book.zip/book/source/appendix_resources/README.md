# 资源链接
* Docker 主站点: https://www.docker.io
* Docker 注册中心API: http://docs.docker.com/reference/api/registry_api/
* Docker Hub API: http://docs.docker.com/reference/api/docker-io_api/
* Docker 远端应用API: http://docs.docker.com/reference/api/docker_remote_api/
* Dockerfile 参考：https://docs.docker.com/reference/builder/
* Dockerfile 最佳实践：https://docs.docker.com/articles/dockerfile_best-practices/
